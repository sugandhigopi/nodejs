const mongoose = require('mongoose');
const LocationlistSchema=mongoose.Schema({
	treeId:{
		type:String,
		required:true
	},
	location:String,
	latLong:{
		type: [Number],  
    	index: '2d' 	
	}
});
const LocationList = module.exports = mongoose.model('LocationList', LocationlistSchema );
module.exports.getList = (coords,maxDistance,limit,callback) => {    
    LocationList.find({
      latLong: {
        $near: coords,
        $maxDistance: maxDistance
      }      
    }).limit(limit).exec(function(err, locations) {    	
      callback(err,locations);
    });
}
module.exports.addList = (newList, callback) => {
    newList.save(callback);
}
module.exports.getbyId = (id, callback) => {
    let query = {treeId: id};   
    LocationList.find(query,callback)
    
}
module.exports.updateById = (query,setvalue, callback) => {  

    LocationList.update(query,setvalue,function(err,res){
    	if(err){
    		console.log(err);
    	}else{
    		console.log(res);
    		callback('',res);
    	}
    })
    
}

