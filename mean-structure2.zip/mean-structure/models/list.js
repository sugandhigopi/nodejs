const mongoose = require('mongoose');
const UserlistSchema=mongoose.Schema({
	title:{
		type:String,
		required:true
	},
	description:String,
	Category:{
		type:String,
		required:true,
		enum:['post','page','blog']
	}
});
const UserList = module.exports = mongoose.model('UserList', UserlistSchema );
module.exports.getAllLists = (callback) => {
    UserList.find(callback);
}
module.exports.addList = (newList, callback) => {
    newList.save(callback);
}

//Here we need to pass an id parameter to BUcketList.remove
module.exports.deleteListById = (id, callback) => {
    let query = {_id: id};
    UserList.remove(query, callback);
}