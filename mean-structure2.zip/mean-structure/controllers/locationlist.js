const express = require('express');
const router = express.Router();
const Location = require('../models/location');
const where = require('node-where');
const multer  = require('multer');
// const csv = require('fast-csv');
// const csv = require('csvtojson');
const csv = require('ya-csv');
router.get('/',(req,res) => {	 
    var limit = req.query.limit || 10;
    var maxDistance = req.query.distance || 8;
    // maxDistance /= 6371;
    console.log(maxDistance);    
    var coords = [];
    coords[0] = req.query.longitude;
    coords[1] = req.query.latitude;

    // find a location
    Location.getList(coords,maxDistance,limit,(err, list) => {
        if(err) {
            res.json({success: false, message: `Error: ${err}`});
        }
        else
            res.json({success:true, list: list});

    });
//}
   // res.send("GET");
});

router.post('/', (req,res,next) => {
            var storage =   multer.diskStorage({
              destination: function (req, file, callback) {               
                callback(null, './');
              },
              filename: function (req, file, callback) {             
                if (file.mimetype == 'text/csv') {
                    var x = file.originalname;
                    var f = x.substr(0, x.lastIndexOf('.'));
                    callback(null, f+'.csv');
                 }else{
                    var err = [{"Error":"Upload Only csv"}]; 
                    callback(err);
                  
                }
              },
              
            });
            
            var upload = multer({ storage: storage}).any();
               upload(req, res, function (err) {
                // console.log(req);
                if (!req.files)
                        return res.status(400).send('No files were uploaded.');
                     
                    var authorFile = req.files[0].path;
                    //console.log(authorFile);
                    var authors = [];
                    var reader = csv.createCsvFileReader(authorFile, { 
                    columnsFromHeader: true }); 
                    reader.addListener('data', function(data) {                        
                           // console.log(data);
                            where.is(data.location, function(err, result) {
                                if (result) {  
                                    //console.log(data.location); console.log(result);                                
                                    let newList = new Location({
                                        treeId: data.treeId,
                                        location: data.location,
                                        latLong: [result.get('lat'),result.get('lng')]
                                    });
                                    var myquery = { treeId: data.treeId};
                                    var newvalues = { $set: {location: data.location, latLong: [result.get('lat'),result.get('lng')] } };
                                    var id = data.treeId;
                        console.log(myquery);console.log(newvalues);console.log(newList);return;
                                     Location.getbyId(id,(err, list) => {
                                        if(err) {
                                            res.json({success: false, message: `Error: ${err}`});
                                        }
                                        else{
                                            if(list.length == 0){
                                                console.log(newList);
                                                Location.addList(newList,(err, list) => {
                                                    if(err) {
                                                        res.json({success: false, message: `Failed to create a new list. Error: ${err}`});

                                                    }
                                                    else
                                                        res.json({success:true, message: "Added successfully."});

                                                });
                                            }else{    
                                                console.log(list.length);
                                                console.log(myquery);
                                                console.log(newvalues);                                 
                                                 Location.updateById(myquery,newvalues,(err, list) => {
                                                    if(err) {
                                                        res.json({success: false, message: `Failed to create a new list. Error: ${err}`});

                                                    }
                                                    else
                                                        res.json({success:true, message: "Added successfully."});

                                                });
                                            }
                                        } 
                                    }); 
                              }
                            });
                        //   

                    });
                           
                    // csv()
                    //     .fromFile(authorFile)
                    //     .on('csv', (csvRow) => {
                    //       csvRow.forEach(function (element) {
                    //         console.log(element);
                    //         // where.is(req.body.location, function(err, result) {
                    //         //     if (result) {
                                   
                    //         //         let newList = new Location({
                    //         //             treeId: req.body.treeId,
                    //         //             location: req.body.location,
                    //         //             latLong: [result.get('lat'),result.get('lng')]
                    //         //         });
                    //         //         console.log(newList);return;
                    //         //     Location.addList(newList,(err, list) => {
                    //         //         if(err) {
                    //         //             res.json({success: false, message: `Failed to create a new list. Error: ${err}`});

                    //         //         }
                    //         //         else
                    //         //             res.json({success:true, message: "Added successfully."});

                    //         //     });
                    //         //     }
                    //         // });
                    //         //console.log(element);
                    //         // Save data on mongo database
                    //         // collection.insertOne({ email: element }, (err, result) => {
                    //         //   if (err) {
                    //         //     console.log(err);
                    //         //   } else {
                    //         //     callback(result);
                    //         //   }
                    //         // });
                    //       }, this);
                    //     })
                    //     .on('done', (error) => {
                    //       console.log('end')
                    // });
                
               });
               

    
    //res.send("POST");

});

module.exports = router;